import os, uuid
from flask import Blueprint, render_template, request, redirect, url_for, flash, current_app
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from . import db
from .models import Product, Order

admin = Blueprint("admin", __name__)

def admin_required(view):
    from functools import wraps
    @wraps(view)
    @login_required
    def wrapper(*args, **kwargs):
        if not current_user.is_admin:
            flash("Admin access required.", "error")
            return redirect(url_for("main.home"))
        return view(*args, **kwargs)
    return wrapper

@admin.route("/")
@admin_required
def dashboard():
    return render_template("admin.html", products=Product.query.order_by(Product.created_at.desc()).all(),
                           orders=Order.query.order_by(Order.created_at.desc()).limit(20).all())

@admin.post("/products/add")
@admin_required
def add_product():
    image_url = request.form.get("image_url", "").strip()
    file = request.files.get("image")
    if file and file.filename:
        filename = secure_filename(file.filename)
        ext = os.path.splitext(filename)[1].lower()
        filename = f"{uuid.uuid4().hex}{ext}"
        path = os.path.join(current_app.root_path, "static", "uploads", filename)
        file.save(path)
        image_url = url_for("static", filename=f"uploads/{filename}")
    p = Product(
        name=request.form["name"], description=request.form.get("description", ""),
        price=float(request.form["price"]), category=request.form["category"],
        sizes=request.form.get("sizes", ""), colors=request.form.get("colors", ""),
        stock=int(request.form.get("stock", 0)), image_url=image_url,
        featured=bool(request.form.get("featured"))
    )
    db.session.add(p)
    db.session.commit()
    flash("Product added successfully.", "success")
    return redirect(url_for("admin.dashboard"))

@admin.post("/products/<int:product_id>/delete")
@admin_required
def delete_product(product_id):
    p = Product.query.get_or_404(product_id)
    db.session.delete(p)
    db.session.commit()
    flash("Product deleted.", "success")
    return redirect(url_for("admin.dashboard"))

@admin.post("/orders/<int:order_id>/status")
@admin_required
def update_order(order_id):
    order = Order.query.get_or_404(order_id)
    order.status = request.form.get("status", "Pending")
    db.session.commit()
    flash("Order status updated.", "success")
    return redirect(url_for("admin.dashboard"))
