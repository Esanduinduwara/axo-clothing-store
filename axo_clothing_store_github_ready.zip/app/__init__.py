import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager

db = SQLAlchemy()
login_manager = LoginManager()

def create_app():
    app = Flask(__name__, instance_relative_config=True)
    os.makedirs(app.instance_path, exist_ok=True)
    os.makedirs(os.path.join(app.root_path, "static", "uploads"), exist_ok=True)

    app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-this-secret-key")
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + os.path.join(app.instance_path, "store.db")
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    app.config["MAX_CONTENT_LENGTH"] = 8 * 1024 * 1024

    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = "auth.login"

    from .models import User, Product, Order, OrderItem
    from .routes import main
    from .auth import auth
    from .admin import admin

    app.register_blueprint(main)
    app.register_blueprint(auth, url_prefix="/auth")
    app.register_blueprint(admin, url_prefix="/admin")

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    with app.app_context():
        db.create_all()
        seed_database()

    return app

def seed_database():
    from .models import Product
    if Product.query.count() > 0:
        return
    products = [
        Product(name="AXO Essential Oversized Tee", description="Heavyweight cotton oversized tee with a clean minimal AXO chest mark.", price=5490, category="T-Shirts", sizes="S,M,L,XL,XXL", colors="Black,White", stock=50, image_url="https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=900&q=85", featured=True),
        Product(name="AXO Shadow Graphic Tee", description="Premium oversized streetwear tee featuring a bold monochrome back graphic.", price=6490, category="T-Shirts", sizes="S,M,L,XL", colors="Black,Charcoal", stock=35, image_url="https://images.unsplash.com/photo-1503341504253-dff4815485f1?auto=format&fit=crop&w=900&q=85", featured=True),
        Product(name="AXO Utility Hoodie", description="Relaxed heavyweight hoodie designed for everyday streetwear layering.", price=10990, category="Hoodies", sizes="S,M,L,XL,XXL", colors="Black,Grey", stock=25, image_url="https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&w=900&q=85", featured=True),
        Product(name="AXO Core Cargo", description="Relaxed-fit cargo trousers with utility pockets and an adjustable waist.", price=8990, category="Bottoms", sizes="28,30,32,34,36", colors="Black,Olive", stock=30, image_url="https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=900&q=85", featured=False),
        Product(name="AXO Studio Cap", description="Structured six-panel cap with subtle embroidered AXO branding.", price=3490, category="Accessories", sizes="One Size", colors="Black,Cream", stock=45, image_url="https://images.unsplash.com/photo-1521369909029-2afed882baee?auto=format&fit=crop&w=900&q=85", featured=False),
        Product(name="AXO Heavyweight Crewneck", description="Premium brushed fleece crewneck with a relaxed silhouette.", price=8990, category="Sweatshirts", sizes="S,M,L,XL", colors="Black,Stone", stock=20, image_url="https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=900&q=85", featured=False),
    ]
    db.session.bulk_save_objects(products)
    db.session.commit()
