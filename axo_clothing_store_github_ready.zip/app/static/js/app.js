const CART_KEY = "axo_cart_v1";

function getCart(){ try { return JSON.parse(localStorage.getItem(CART_KEY)) || []; } catch(e){ return []; } }
function saveCart(cart){ localStorage.setItem(CART_KEY, JSON.stringify(cart)); updateCartCount(); }
function updateCartCount(){ const n = getCart().reduce((sum,i)=>sum+i.quantity,0); const el=document.getElementById("cartCount"); if(el) el.textContent=n; }
function toggleSearch(){ document.getElementById("searchBar").classList.toggle("open"); }
function toggleMenu(){ document.getElementById("mobileNav").classList.toggle("open"); }
function choose(btn,type){ btn.parentElement.querySelectorAll(".choice-btn").forEach(b=>b.classList.remove("selected")); btn.classList.add("selected"); btn.dataset.type=type; }
function changeQty(delta){ const el=document.getElementById("qty"); if(!el)return; el.textContent=Math.max(1,parseInt(el.textContent)+delta); }
function addProduct(id,name,price,image,size,color){
  const selectedSize=document.querySelector('.choice-btn.selected[data-type="size"]')?.textContent || size;
  const selectedColor=document.querySelector('.choice-btn.selected[data-type="color"]')?.textContent || color;
  const quantity=parseInt(document.getElementById("qty")?.textContent || "1");
  const cart=getCart(); const existing=cart.find(i=>i.id===id && i.size===selectedSize && i.color===selectedColor);
  if(existing) existing.quantity+=quantity;
  else cart.push({id,name,price,image,size:selectedSize,color:selectedColor,quantity});
  saveCart(cart); toast("Added to your bag.");
}
function removeItem(index){ const c=getCart(); c.splice(index,1); saveCart(c); renderCart(); }
function setItemQty(index,delta){ const c=getCart(); c[index].quantity=Math.max(1,c[index].quantity+delta); saveCart(c); renderCart(); }
function money(n){ return "LKR " + Number(n).toLocaleString("en-LK",{maximumFractionDigits:0}); }
function renderCart(){
  const el=document.getElementById("cartContent"); if(!el)return; const c=getCart();
  if(!c.length){ el.innerHTML=`<div class="empty cart-empty"><h2>Your bag is empty.</h2><p>Find something you’ll want to wear every day.</p><a class="btn btn-dark" href="/shop">SHOP COLLECTION ↗</a></div>`; return; }
  const subtotal=c.reduce((s,i)=>s+i.price*i.quantity,0);
  el.innerHTML=`<div class="cart-layout"><div class="cart-items">${c.map((i,idx)=>`<div class="cart-item"><img src="${i.image}" alt="${i.name}"><div class="cart-item-info"><a href="/product/${i.id}">${i.name}</a><small>${i.size} · ${i.color}</small><div class="mini-qty"><button onclick="setItemQty(${idx},-1)">−</button><span>${i.quantity}</span><button onclick="setItemQty(${idx},1)">+</button></div></div><strong>${money(i.price*i.quantity)}</strong><button class="remove" onclick="removeItem(${idx})">×</button></div>`).join("")}</div><aside class="cart-summary"><h3>SUMMARY</h3><div><span>Subtotal</span><strong>${money(subtotal)}</strong></div><div><span>Shipping</span><strong>${subtotal>=15000?"FREE":money(850)}</strong></div><hr><div class="total"><span>Total</span><strong>${money(subtotal+(subtotal>=15000?0:850))}</strong></div><a class="btn btn-dark wide" href="/checkout">CHECKOUT ↗</a><p class="secure">Secure checkout · Easy returns</p></aside></div>`;
}
function renderCheckout(){
  const el=document.getElementById("checkoutSummary"); if(!el)return; const c=getCart();
  if(!c.length){ el.innerHTML='<p>Your bag is empty.</p><a href="/shop">Return to shop →</a>'; return; }
  const subtotal=c.reduce((s,i)=>s+i.price*i.quantity,0), shipping=subtotal>=15000?0:850;
  el.innerHTML=c.map(i=>`<div class="summary-item"><span>${i.name} × ${i.quantity}</span><strong>${money(i.price*i.quantity)}</strong></div>`).join("")+`<hr><div class="summary-item"><span>Shipping</span><strong>${shipping?money(shipping):"FREE"}</strong></div><div class="summary-total"><span>Total</span><strong>${money(subtotal+shipping)}</strong></div>`;
}
async function submitOrder(e){
  e.preventDefault(); const form=e.target, error=document.getElementById("checkoutError"), cart=getCart();
  if(!cart.length){error.textContent="Your bag is empty.";return;}
  const customer=Object.fromEntries(new FormData(form).entries());
  try{
    const res=await fetch("/api/orders",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({customer,items:cart})});
    const data=await res.json(); if(!res.ok) throw new Error(data.error||"Could not place order.");
    localStorage.removeItem(CART_KEY); window.location.href="/order-success/"+data.order_id;
  }catch(err){error.textContent=err.message;}
}
function subscribe(e){e.preventDefault();document.getElementById("subscribeMsg").textContent="You’re on the list. Welcome to AXO.";e.target.reset();}
function toast(msg){const t=document.createElement("div");t.className="toast";t.textContent=msg;document.body.appendChild(t);setTimeout(()=>t.remove(),2200);}
document.addEventListener("DOMContentLoaded",()=>{updateCartCount();renderCart();});
