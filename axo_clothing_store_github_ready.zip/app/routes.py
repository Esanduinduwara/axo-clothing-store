from flask import Blueprint, render_template, request, jsonify, redirect, url_for, flash
from flask_login import current_user
from . import db
from .models import Product, Order, OrderItem

main = Blueprint("main", __name__)

@main.route("/")
def home():
    featured = Product.query.filter_by(featured=True).order_by(Product.created_at.desc()).all()
    latest = Product.query.order_by(Product.created_at.desc()).limit(8).all()
    return render_template("index.html", featured=featured, latest=latest)

@main.route("/shop")
def shop():
    category = request.args.get("category", "")
    q = request.args.get("q", "")
    query = Product.query
    if category:
        query = query.filter_by(category=category)
    if q:
        like = f"%{q}%"
        query = query.filter(db.or_(Product.name.ilike(like), Product.description.ilike(like)))
    products = query.order_by(Product.created_at.desc()).all()
    categories = [r[0] for r in db.session.query(Product.category).distinct().all()]
    return render_template("shop.html", products=products, categories=categories, selected=category, q=q)

@main.route("/product/<int:product_id>")
def product(product_id):
    item = Product.query.get_or_404(product_id)
    related = Product.query.filter(Product.category == item.category, Product.id != item.id).limit(4).all()
    return render_template("product.html", product=item, related=related)

@main.route("/cart")
def cart():
    return render_template("cart.html")

@main.route("/checkout")
def checkout():
    return render_template("checkout.html")

@main.route("/order-success/<int:order_id>")
def order_success(order_id):
    order = Order.query.get_or_404(order_id)
    return render_template("success.html", order=order)

@main.post("/api/orders")
def create_order():
    data = request.get_json(silent=True) or {}
    items = data.get("items", [])
    if not items:
        return jsonify({"error": "Your cart is empty."}), 400

    customer = data.get("customer", {})
    required = ["name", "email", "address"]
    if any(not customer.get(k) for k in required):
        return jsonify({"error": "Please complete all required delivery fields."}), 400

    total = 0
    order_items = []
    for cart_item in items:
        product = Product.query.get(int(cart_item.get("id", 0)))
        qty = max(1, int(cart_item.get("quantity", 1)))
        if not product or product.stock < qty:
            return jsonify({"error": f"{product.name if product else 'A product'} is out of stock."}), 400
        total += product.price * qty
        order_items.append((product, qty, cart_item.get("size", ""), cart_item.get("color", "")))

    order = Order(
        user_id=current_user.id if current_user.is_authenticated else None,
        customer_name=customer["name"], email=customer["email"],
        phone=customer.get("phone", ""), address=customer["address"],
        city=customer.get("city", ""), total=total
    )
    db.session.add(order)
    db.session.flush()

    for product, qty, size, color in order_items:
        product.stock -= qty
        db.session.add(OrderItem(order_id=order.id, product_id=product.id,
                                 product_name=product.name, size=size, color=color,
                                 quantity=qty, price=product.price))
    db.session.commit()
    return jsonify({"success": True, "order_id": order.id})
