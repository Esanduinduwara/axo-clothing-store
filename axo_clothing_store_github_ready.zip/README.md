# AXO Clothing — Full-Stack E-Commerce Store

A modern, responsive clothing e-commerce website built with **Python Flask + SQLite + HTML + CSS + JavaScript**.

## Features

- Premium responsive storefront
- Product catalogue and category filtering
- Product search
- Product detail pages
- Size and colour selection
- Shopping cart stored in browser localStorage
- Quantity controls and automatic totals
- Checkout and order creation
- SQLite database
- Customer registration/login
- Admin dashboard
- Add products with image URL or image upload
- Delete products
- Manage order status
- Featured products
- Newsletter UI
- Mobile navigation
- GitHub-ready project structure

## Tech Stack

- Python 3.11+
- Flask
- Flask-SQLAlchemy
- Flask-Login
- SQLite
- HTML5
- CSS3
- Vanilla JavaScript

## Run locally

```bash
git clone YOUR_REPOSITORY_URL
cd axo_clothing_store

python -m venv venv

# Windows
venv\Scripts\activate

# macOS/Linux
source venv/bin/activate

pip install -r requirements.txt
python run.py
```

Open:

`http://127.0.0.1:5000`

The SQLite database is automatically created in `instance/store.db`.

## Create an admin account

The registration system creates normal customer accounts. To make an account an admin, open Python:

```bash
python
```

Then:

```python
from app import create_app, db
from app.models import User

app = create_app()

with app.app_context():
    user = User.query.filter_by(email="YOUR_EMAIL").first()
    user.is_admin = True
    db.session.commit()
```

Then visit:

`http://127.0.0.1:5000/admin`

## Important before production

This project includes a **demo checkout**. It creates orders in the database but does not charge a card.

For real payments, integrate a payment provider such as Stripe, PayHere, or another gateway available in your market.

Also change:

- `SECRET_KEY`
- Admin credentials
- Product images
- Contact information
- Shipping fees
- Return policy
- Privacy policy
- Terms and conditions

## GitHub

Create a GitHub repository and push the project:

```bash
git init
git add .
git commit -m "Initial AXO clothing store"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/axo-clothing-store.git
git push -u origin main
```

### Important: GitHub Pages

GitHub Pages can host the **static frontend**, but it cannot run this Flask/Python server or SQLite database.

For the full website, deploy the Flask application to a Python-compatible hosting service such as Render, Railway, Fly.io, PythonAnywhere, or your own VPS.

GitHub should be used for the source-code repository. Your production URL should point to the deployed Flask server.

## Suggested production architecture

```text
Customer
   ↓
Flask Web App
   ↓
SQLite / PostgreSQL
   ↓
Payment Gateway
```

For a larger production store, replace SQLite with PostgreSQL and store uploaded product images in cloud storage.

## Project structure

```text
axo_clothing_store/
├── app/
│   ├── __init__.py
│   ├── models.py
│   ├── routes.py
│   ├── auth.py
│   ├── admin.py
│   ├── templates/
│   └── static/
├── instance/
├── run.py
├── requirements.txt
├── .gitignore
└── README.md
```

## Brand

AXO Clothing  
Modern streetwear for the next generation.
